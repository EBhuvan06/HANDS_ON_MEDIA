import time

class AccessControl:
    """Gate gesture commands behind face recognition & session management."""

    def __init__(self, face_recognizer):
        self.recognizer = face_recognizer
        self.active_session = {
            'user'         : None,
            'start_time'   : None,
            'last_seen'    : None,
            'confidence'   : 0,
            'gesture_count': 0
        }
        self.session_timeout      = 30   # seconds before session expires
        self.confidence_threshold = 0.65
        self.min_frames_for_auth  = 3
        self.detection_history    = []
        self.detection_buffer_size = 3

    def check_authorization(self, detected_face, confidence):
        """
        Buffer recent detections and decide whether to grant/continue a session.

        Args:
            detected_face : dict with keys 'bbox', 'confidence' (from FaceDetector)
            confidence    : float avg confidence for the frame

        Returns:
            (authorized: bool, username: str|None, message: str)
        """
        self.detection_history.append({
            'face'      : detected_face,
            'confidence': confidence,
            'timestamp' : time.time()
        })
        if len(self.detection_history) > self.detection_buffer_size:
            self.detection_history.pop(0)

        # Need enough frames before committing
        if len(self.detection_history) < self.min_frames_for_auth:
            return False, None, "Scanning face..."

        # Pick the highest-confidence recent detection for recognition
        best = max(self.detection_history, key=lambda x: x['confidence'])

        # face_recognition.recognize expects (face_roi, face_detection_obj)
        # best['face'] here is the dict from FaceDetector, not the MP object.
        # Access the raw MediaPipe object stored under key 'mp_detection' if
        # available, else fall back to the dict itself (backward compat).
        mp_obj = best['face'].get('mp_detection') if isinstance(best['face'], dict) else best['face']

        user, recog_conf = self.recognizer.recognize(None, mp_obj)

        if user is not None and recog_conf >= self.confidence_threshold:
            if self.active_session['user'] != user:
                # New user starting a session
                self.active_session = {
                    'user'         : user,
                    'start_time'   : time.time(),
                    'last_seen'    : time.time(),
                    'confidence'   : recog_conf,
                    'gesture_count': 0
                }
                message = f"Welcome {user}!"
            else:
                # Existing session refresh
                self.active_session['last_seen']   = time.time()
                self.active_session['confidence']  = recog_conf
                message = f"Authorized: {user}"
            return True, user, message
        else:
            message = (
                "Unknown user - Access denied"
                if user is None
                else f"Low confidence - Retry ({recog_conf:.0%})"
            )
            self.active_session['user'] = None
            return False, None, message

    def is_authorized(self):
        """
        Check whether the current session is still valid (not timed out).

        Returns:
            (authorized: bool, username: str|None, message: str)
        """
        if self.active_session['user'] is None:
            return False, None, "No active session"

        elapsed = time.time() - self.active_session['last_seen']
        if elapsed > self.session_timeout:
            self.active_session['user'] = None
            return False, None, "Session timeout"

        return True, self.active_session['user'], "Authorized"

    def log_gesture(self, gesture_name, success=True):
        """Increment gesture counter for the active session."""
        if self.active_session['user']:
            self.active_session['gesture_count'] += 1

    def get_session_info(self):
        """Return a snapshot of the active session."""
        user = self.active_session['user']
        return {
            'user'           : user,
            'active'         : user is not None,
            'uptime_seconds' : (time.time() - self.active_session['start_time']) if user else 0,
            'gesture_count'  : self.active_session['gesture_count'],
            'confidence'     : self.active_session['confidence']
        }
