import mediapipe as mp
import cv2
import numpy as np

class FaceDetector:
    """Detects faces in a frame using MediaPipe."""

    def __init__(self):
        # model_selection removed: not supported in MediaPipe 0.10+
        self.face_detection = mp.solutions.face_detection.FaceDetection(
            min_detection_confidence=0.6
        )

    def detect(self, frame):
        """
        Detect faces in frame.
        Returns: detections list, avg_confidence, first detection object
        """
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detection.process(rgb)

        if not results.detections:
            return [], 0, None

        h, w = frame.shape[:2]
        detections = []
        confidences = []

        for detection in results.detections:
            bbox = detection.location_data.bounding_box
            confidence = detection.score[0]

            x_min = int(bbox.xmin * w)
            y_min = int(bbox.ymin * h)
            width  = int(bbox.width  * w)
            height = int(bbox.height * h)

            detections.append({
                'bbox'        : (x_min, y_min, width, height),
                'confidence'  : confidence,
                'mp_detection': detection   # raw MediaPipe object for recognition
            })
            confidences.append(confidence)

        avg_confidence = float(np.mean(confidences)) if confidences else 0.0
        return detections, avg_confidence, results.detections[0]

    def get_face_roi(self, frame, detection):
        """Extract face region of interest from frame."""
        x, y, w, h = detection['bbox']

        padding = int(h * 0.1)
        x = max(0, x - padding)
        y = max(0, y - padding)
        w = min(frame.shape[1] - x, w + 2 * padding)
        h = min(frame.shape[0] - y, h + 2 * padding)

        return frame[y:y + h, x:x + w], (x, y, w, h)
