import cv2
import numpy as np
from scipy.spatial import distance
import json
import os

class FaceRecognizer:
    """Recognizes enrolled users from MediaPipe face landmark data."""

    def __init__(self, database_path="data/enrolled_users.json"):
        self.database_path = database_path
        self.enrolled_users = {}
        self.confidence_threshold = 0.65
        self.load_database()

    # ------------------------------------------------------------------ I/O --
    def load_database(self):
        """Load enrolled users from JSON database."""
        if os.path.exists(self.database_path):
            with open(self.database_path, 'r') as f:
                self.enrolled_users = json.load(f)
            print(f"[+] Loaded {len(self.enrolled_users)} enrolled user(s)")
        else:
            print("[!] No database found - will be created on first enrollment")

    def save_database(self):
        """Persist enrolled users to JSON database."""
        os.makedirs(os.path.dirname(self.database_path) or '.', exist_ok=True)
        with open(self.database_path, 'w') as f:
            json.dump(self.enrolled_users, f, indent=4)

    # ---------------------------------------------------------- landmarks ----
    def extract_landmarks(self, face_detection):
        """
        Extract normalised landmark vector from a MediaPipe detection object.
        Returns a 1-D numpy array.
        """
        keypoints = face_detection.location_data.relative_keypoints
        landmarks = np.array([[kp.x, kp.y] for kp in keypoints], dtype=np.float32)

        # Normalise: centre + scale
        center = landmarks.mean(axis=0)
        landmarks -= center
        std = landmarks.std()
        if std > 0:
            landmarks /= std

        return landmarks.flatten()

    # ------------------------------------------------------- recognition ----
    def recognize(self, face_roi, face_detection):
        """
        Identify which enrolled user a face belongs to.

        Args:
            face_roi       : cropped face image (unused currently, reserved for
                             future embedding-based recognition)
            face_detection : MediaPipe detection object

        Returns:
            (username, confidence)  or  (None, score) if below threshold
        """
        if not self.enrolled_users:
            return None, 0.0

        current = self.extract_landmarks(face_detection)

        best_user  = None
        best_score = 0.0

        for username, data in self.enrolled_users.items():
            stored = np.array(data['face_landmarks'], dtype=np.float32)

            # Guard: landmark vectors must be the same length
            if stored.shape != current.shape:
                continue

            dist = distance.euclidean(current, stored)
            # Map distance → [0, 1] confidence  (0 distance = 1.0 confidence)
            score = max(0.0, 1.0 - dist / 2.0)

            if score > best_score:
                best_score = score
                best_user  = username

        if best_score >= self.confidence_threshold:
            return best_user, best_score
        return None, best_score

    # --------------------------------------------------------- enrolment ----
    def enroll_user(self, username, face_samples):
        """
        Enrol a new user using multiple face samples.

        Args:
            username     : string identifier for the user
            face_samples : list of (face_detection, face_roi) tuples

        Returns:
            True on success, False otherwise
        """
        if username in self.enrolled_users:
            print(f"[!] User '{username}' already exists!")
            return False

        if len(face_samples) < 3:
            print("[!] Need at least 3 face samples for enrolment")
            return False

        all_landmarks = []
        for face_detection, face_roi in face_samples:
            try:
                lm = self.extract_landmarks(face_detection)
                all_landmarks.append(lm)
            except Exception as e:
                print(f"[!] Skipping bad sample: {e}")

        if len(all_landmarks) < 3:
            print("[!] Too many bad samples - enrolment failed")
            return False

        avg_landmarks = np.mean(all_landmarks, axis=0).tolist()

        self.enrolled_users[username] = {
            'face_landmarks': avg_landmarks,
            'enrolled_time' : str(np.datetime64('now')),
            'num_samples'   : len(face_samples),
            'status'        : 'active'
        }

        self.save_database()
        print(f"[+] User '{username}' enrolled successfully with {len(face_samples)} samples!")
        return True

    # ------------------------------------------------------------ utils ----
    def list_users(self):
        """Return list of enrolled usernames."""
        return list(self.enrolled_users.keys())

    def delete_user(self, username):
        """Remove an enrolled user from the database."""
        if username in self.enrolled_users:
            del self.enrolled_users[username]
            self.save_database()
            print(f"[+] User '{username}' deleted")
            return True
        print(f"[!] User '{username}' not found")
        return False
