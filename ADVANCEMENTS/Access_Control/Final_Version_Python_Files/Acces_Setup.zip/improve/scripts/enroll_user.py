#!/usr/bin/env python3
import cv2
import os
import sys

# Support running from: ~/improve/scripts/enroll_user.py  OR  ~/improve/enroll_user.py
script_dir  = os.path.dirname(os.path.abspath(__file__))
project_root = script_dir if os.path.isdir(os.path.join(script_dir, 'modules')) \
               else os.path.join(script_dir, '..')
sys.path.insert(0, os.path.abspath(project_root))

from modules.face_detection   import FaceDetector
from modules.face_recognition import FaceRecognizer


class UserEnrollment:
    def __init__(self):
        self.face_detector  = FaceDetector()
        self.face_recognizer = FaceRecognizer()
        self.num_samples    = 10

    def run(self):
        print("\n" + "=" * 60)
        print("MPV GESTURE CONTROL - USER ENROLLMENT")
        print("=" * 60)

        username = input("\nEnter username: ").strip()
        if not username:
            print("[x] Username cannot be empty")
            return False

        if username in self.face_recognizer.list_users():
            print(f"[x] User '{username}' already exists!")
            return False

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[x] Could not open camera")
            return False

        print(f"\nEnrolling user: {username}")
        print(f"Need to capture {self.num_samples} images.")
        print("Press SPACE to capture | Q to cancel\n")

        captures     = 0
        face_samples = []

        while captures < self.num_samples:
            ret, frame = cap.read()
            if not ret:
                print("[x] Camera read failed")
                break

            frame = cv2.flip(frame, 1)
            detections, conf, face_detection_obj = self.face_detector.detect(frame)

            cv2.putText(frame, f"Capture {captures + 1}/{self.num_samples}",
                        (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            if not detections:
                cv2.putText(frame, "No face detected - please look at camera",
                            (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                cv2.imshow(f"Enrollment - {username}", frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                continue

            det = detections[0]   # highest-confidence face
            x, y, w, h = det['bbox']
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, f"Conf: {conf:.1%}  |  Press SPACE to capture",
                        (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)

            cv2.imshow(f"Enrollment - {username}", frame)
            key = cv2.waitKey(1) & 0xFF

            if key == ord(' '):
                face_roi, _ = self.face_detector.get_face_roi(frame, det)
                # Store the raw MediaPipe detection object (not the dict)
                mp_det = det.get('mp_detection', face_detection_obj)
                face_samples.append((mp_det, face_roi))
                captures += 1
                print(f"  [+] Captured {captures}/{self.num_samples}")

            elif key == ord('q'):
                print("\n[x] Enrollment cancelled by user")
                cap.release()
                cv2.destroyAllWindows()
                return False

        cap.release()
        cv2.destroyAllWindows()

        if len(face_samples) < 3:
            print(f"\n[x] Not enough captures ({len(face_samples)}/3 minimum)")
            return False

        print("\nProcessing face data...")
        success = self.face_recognizer.enroll_user(username, face_samples)

        if success:
            print(f"\n{'='*60}")
            print(f"  SUCCESS! User '{username}' enrolled.")
            print(f"  They can now control media with gestures.")
            print(f"{'='*60}")

        return success


if __name__ == "__main__":
    enrollment = UserEnrollment()
    enrollment.run()
